<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('crud/index');
	}
//Insert data
	public function insert(){

		$this->form_validation->set_rules("username","User Name ","required|alpha");
		$this->form_validation->set_rules("age","age ","required");
		$this->form_validation->set_rules("country","country ","required|alpha");
			if($this->form_validation->run()){
				$this->load->model("crud_model");
				$data=array(
					"username"=>$this->input->post("username"),
					"age"=>$this->input->post("age"),
					"country"=>$this->input->post("country")
				);
				$result=$this->crud_model->insertdata($data);
				if($result){
					echo 1;
				}else{
					echo 0;
				}
			}
			else{
				$this->load->view('crud/index');
			}
	}

	//		Select Data
		public function getdata()
		{
			$output = "";
			$query="";
			$this->load->model("crud_model");
			if($this->input->post("query")){
				$query=$this->input->post("query");
			}
			$myrow = $this->crud_model->getdata($query);
			if (count($myrow) > 0) {
				echo "<span class='w3-large mb-4'>".$query."</span>";
				$output .= "<table class='w3-table-all table-bordered mt-3 '>
					<tr>
						<th>Id</th>
						<th>Name</th>
						<th>Age</th>
						<th>Country</th>
						<th>Edit</th>
						<th>Delete</th>
					</tr>
					";
				$i=1;
				foreach ($myrow as $row) {
					$output .= '
					<tr>
						<td>' . $i . '</td>
						<td>' . ucfirst($row->username ). '</td>
						<td>' . ucfirst($row->age ). '</td>
						<td>' . ucfirst($row->country ). '</td>
						<td> <a href="#" data-id=' . $row->id . ' id="edit" class="btn w3-blue">Edit</a></td>
						<td> <a href="#" data-id=' . $row->id . ' id="del" class="btn w3-red">Delete</a></td>
					</tr>
					';
					$i++;
				}
				$output .= "</table>";
				echo $output;
			} else {
				echo "<span class='w3-xxxlarge w3-text-red'>".ucfirst($query)." "."Record not Found</span>";
			}
		}

//		Delete
	public function delete(){
		$this->load->model("crud_model");
		$id=$this->input->post("id");
		$result=$this->crud_model->delete($data,array("id"=>$id));
		if($result){
			echo 1;
		}
		else{
			echo 0;
		}
	}
// update data
	public function update(){
		$this->load->model("crud_model");
		$id=$this->input->post("edit_id");
		if($post=$this->crud_model->update($id)){
			$data=array("data"=>"success","post"=>$post);
		}
		echo json_encode($data);
	}
// Save update data
	public function saveupdate(){
		$this->form_validation->set_rules("username","User Name ","required|alpha");
		$this->form_validation->set_rules("age","age ","required");
		$this->form_validation->set_rules("country","country ","required|alpha");
		if($this->form_validation->run()){
			$this->load->model("crud_model");
				$data["id"]=$this->input->post("id");
				$data["username"]=$this->input->post("username");
				$data["age"]=$this->input->post("age");
				$data["country"]=$this->input->post("country");
			$result=$this->crud_model->saveupdate($data);
			if($result){
				echo 1;
			}else{
				echo 0;
			}
		}
		else{
			$this->load->view('crud/index');
		}
	}
}
