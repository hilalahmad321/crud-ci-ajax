<?php
class Crud_model extends CI_Model{

//	Insert data
	public function insertdata($data){
		$result=$this->db->insert("student",$data);
		return $result;
	}

//	Search and Select data
	public function getdata($query){
		if($query != ''){
			$this->db->like('username',$query);
			$this->db->or_like('age',$query);
			$this->db->or_like('country',$query);
		}
		$result=$this->db->order_by("id","DESC")
						->get("student");
		return $result->result();
	}

//	delete
	public function delete($data,$where){
		$result=$this->db->delete("student",$where);
		return $result;
	}
//  update data
	public function update($id){
		$result=$this->db->select("*")
						->from("student")
						->where("id",$id)
						->get();
		return $result->row();
	}
//  save update data
 	public function saveupdate($data){
		$result=$this->db->update("student",$data,array("id"=>$data["id"]));
		return $result;
	}
}
