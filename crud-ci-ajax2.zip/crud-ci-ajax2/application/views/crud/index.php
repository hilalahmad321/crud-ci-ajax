<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport"
		  content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="<?php echo base_url("assets/css/bootstrap.css")?>">
	<link rel="stylesheet" href="<?php echo base_url("assets/css/w3.css")?>">
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
	<title>Document</title>
</head>
<body>

<div class="container-fluid bg-dark p-4">
	<h1 class=" w3-center text-white ">Crud in codeigniter</h1>
</div>

<div class="container mt-5">
	<!-- Button trigger modal -->
	<button type="button" class="btn btn-primary w3-right" onclick="document.getElementById('id01').style.display='block'">
		Add Record
	</button>

	<input type="text" name="search" id="search" class="form-control mt-5" placeholder="Search Here....">
	<!-- Modal -->
	<div class="w3-modal" id="id01">
		<div class="w3-modal-content w3-animate-top">
			<span onclick="document.getElementById('id01').style.display='none'" class="w3-display-topright mt-3 mr-2 btn w3-red">&times;</span>
			<form  class="p-5">
				<div class="form-group">
					<label for="">Enter your First name</label>
					<input type="text" name="username" id="username" class="form-control">
					<?php echo form_error("username");?>
				</div>
				<div class="form-group">
					<label for="">Enter your Last name</label>
					<input type="text" name="age" id="age" class="form-control">
					<?php echo form_error("age");?>
				</div>
				<div class="form-group">
					<label for="">Enter your Last name</label>
					<input type="text" name="country" id="country" class="form-control">
					<?php echo form_error("country");?>
				</div>
				<button type="submit" class="btn btn-primary" name="submit" id="submit">Submit</button>
			</form>
		</div>
	</div>

<!--	update model-->
	<div class="w3-modal" id="id02">
		<div class="w3-modal-content w3-animate-top">
			<span onclick="document.getElementById('id02').style.display='none'" class="w3-display-topright mt-3 mr-2 btn w3-red">&times;</span>
<!--			--><?php
//			foreach ($myrow as $row) {
//			?>
			<form  class="p-5">
				<div class="form-group">
					<input type="hidden" name="edit_username" value="" id="edit_id" class="form-control">
					<label for="">Enter your First name</label>
					<input type="text" name="edit_username" value="" id="edit_username" class="form-control">
					<?php echo form_error("username");?>
				</div>
				<div class="form-group">
					<label for="">Enter your Last name</label>
					<input type="text" name="age" id="edit_age" class="form-control">
					<?php echo form_error("age");?>
				</div>
				<div class="form-group">
					<label for="">Enter your Last name</label>
					<input type="text" name="country" id="edit_country" class="form-control">
					<?php echo form_error("country");?>
				</div>
				<button type="submit" class="btn btn-primary" name="submit" id="update">Update</button>
			</form>
<!--			--><?php
//			}
//			?>
		</div>
	</div>
</div>
<div class="container mt-5">
	<div class="table-content"></div>
</div>
<script src="<?php echo base_url("assets/js/jquery.js")?>"></script>
<script src="<?php echo base_url("assets/js/bootstrap.js")?>"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
	$(document).ready(function(){
		// Select Data
		function loaddata(query){
			$.ajax({
				url: "<?php echo base_url() . 'welcome/getdata'?>",
				type: "POST",
				data:{
					query:query
				},
				success: function (data) {
					$(".table-content").html(data);
				}
			})
		}
		loaddata();

		//Search data
		$("#search").on("keyup",function (){
			var search = $(this).val();
			// alert(search)
			if(search != ""){
				loaddata(search);
			}else{
				loaddata();
			}
		})
		// Insert data
		$(document).on("click","#submit",function(e){
			e.preventDefault();
			var username=$("#username").val();
			var age=$("#age").val();
			var country=$("#country").val();
			$("form").trigger("reset");
			$(".w3-modal").hide();
				$.ajax({
					url:"<?php echo base_url().'welcome/insert'?>",
					type:"POST",
					data:{
						username:username,
						age:age,
						country:country
					},
					success:function (data) {
						loaddata();
						if(data==1){
							Command: toastr["success"]("Data insert successfully");
							toastr.options = {
								"closeButton": true,
								"debug": false,
								"newestOnTop": false,
								"progressBar": false,
								"positionClass": "toast-top-right",
								"preventDuplicates": false,
								"onclick": null,
								"showDuration": "300",
								"hideDuration": "1000",
								"timeOut": "5000",
								"extendedTimeOut": "1000",
								"showEasing": "swing",
								"hideEasing": "linear",
								"showMethod": "fadeIn",
								"hideMethod": "fadeOut"
							}
						}else{
							Command: toastr["error"]("All field is required");

							toastr.options = {
								"closeButton": true,
								"debug": false,
								"newestOnTop": false,
								"progressBar": false,
								"positionClass": "toast-top-right",
								"preventDuplicates": false,
								"onclick": null,
								"showDuration": "300",
								"hideDuration": "1000",
								"timeOut": "5000",
								"extendedTimeOut": "1000",
								"showEasing": "swing",
								"hideEasing": "linear",
								"showMethod": "fadeIn",
								"hideMethod": "fadeOut"
						}
					}
				}
			});
		});
		// Delete Data
		$(document).on("click","#del",function (e){
			e.preventDefault();
			var id=$(this).data("id");
			var element=this;
			if(id==""){
				alert("Id is required")
			}else{
				const swalWithBootstrapButtons = Swal.mixin({
					customClass: {
						confirmButton: 'btn btn-success',
						cancelButton: 'btn btn-danger mr-3'
					},
					buttonsStyling: false
				})

				swalWithBootstrapButtons.fire({
					title: 'Are you sure?',
					text: "You won't be able to revert this!",
					icon: 'warning',
					showCancelButton: true,
					confirmButtonText: 'Yes, delete it!',
					cancelButtonText: 'No, cancel!',
					reverseButtons: true
				}).then((result) => {
					if (result.isConfirmed) {
						$.ajax({
							url:"<?php echo base_url().'welcome/delete'?>",
							type:"POST",
							data:{
								id:id
							},
							success:function (data){
								loaddata();
								$(element).closest("tr").fadeOut(1000);
							}
						});
						swalWithBootstrapButtons.fire(
							'Deleted!',
							'Your file has been deleted.',
							'success'
						)
					} else if (
						/* Read more about handling dismissals below */
						result.dismiss === Swal.DismissReason.cancel
					) {
						swalWithBootstrapButtons.fire(
							'Cancelled',
							'Your imaginary file is safe :)',
							'error'
						)
					}
				});
			}
		});
	// Select data for update
	$(document).on("click","#edit",function (e){
		e.preventDefault();
		var edit_id=$(this).data("id");
		$("#id02").show();
		var model=this;
		if(edit_id==""){
			alert("Edit id is required");
		}else{
			$.ajax({
				url:"<?php echo base_url().'welcome/update'?>",
				type:"POST",
				dataType:"json",
				data:{
					edit_id:edit_id
				},
				success:function (data){
					if(data.data=="success"){
						$("#edit_id").val(data.post.id)
						$("#edit_username").val(data.post.username)
						$("#edit_age").val(data.post.age)
						$("#edit_country").val(data.post.country)
					}
				}
			});
		}
	});

	// Update Data
	$("#update").on("click",function (e){
		e.preventDefault();
		var id=$("#edit_id").val();
		var username=$("#edit_username").val();
		var age=$("#edit_age").val();
		var country=$("#edit_country").val();
		$("#id02").hide();
		$.ajax({
			url:"<?php echo base_url().'welcome/saveupdate'?>",
			type:"POST",
			data:{
				id:id,
				username:username,
				age:age,
				country:country
			},
			success:function (data){
				loaddata();
				if(data==1){
					Command: toastr["success"]("Data Update successfully");
					toastr.options = {
						"closeButton": true,
						"debug": false,
						"newestOnTop": false,
						"progressBar": false,
						"positionClass": "toast-top-right",
						"preventDuplicates": false,
						"onclick": null,
						"showDuration": "300",
						"hideDuration": "1000",
						"timeOut": "5000",
						"extendedTimeOut": "1000",
						"showEasing": "swing",
						"hideEasing": "linear",
						"showMethod": "fadeIn",
						"hideMethod": "fadeOut"
					}
				}
				else{
					Command: toastr["error"]("All field is required");

					toastr.options = {
						"closeButton": true,
						"debug": false,
						"newestOnTop": false,
						"progressBar": false,
						"positionClass": "toast-top-right",
						"preventDuplicates": false,
						"onclick": null,
						"showDuration": "300",
						"hideDuration": "1000",
						"timeOut": "5000",
						"extendedTimeOut": "1000",
						"showEasing": "swing",
						"hideEasing": "linear",
						"showMethod": "fadeIn",
						"hideMethod": "fadeOut"
					}
				}
			}
		});
	});
	});
</script>
</body>
</html>
